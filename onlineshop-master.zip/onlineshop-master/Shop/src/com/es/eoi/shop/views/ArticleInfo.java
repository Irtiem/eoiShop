package com.es.eoi.shop.views;

public class ArticleInfo {
	
	

}
