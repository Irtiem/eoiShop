package com.es.eoi.shop.entities;

public class User {

}
